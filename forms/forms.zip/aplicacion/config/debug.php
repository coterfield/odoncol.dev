<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['enable_firephp'] = true;

/* End of file email.php */
/* Location: ./application/config/email.php */