
			</div>
			<!-- END WRAPPER-CONTENT -->

			<!-- BEGIN WRAPPER -->
			<div id="wrapper-footer">

				<div id="footer">

					<div class="widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="textwidget">Teléfono: 204-1000</br>
							Correo: col@col.org.pe
						</div>
					</div>

					<div class="widget">
						<h3 class="widget-title">Sedes</h3>
						<div class="textwidget">
							<p>Sede Miraflores: Calle Carlos Tenaud 255. Miraflores, Lima - Perú.</p>
							<p>Ver otras sedes</p>
						</div>
					</div>

					<div class="widget last">
						<h3 class="widget-title">Categorías</h3>
						<div class="tagcloud">
							<a href='http://www.col.org.pe/web/category/eventos-culturales/' class='tag-link-9' title='2 temas' style='font-size: 10.3773584906pt;'>El COL recomienda</a>
							<a href='http://www.col.org.pe/web/category/eventos-odontologicos/' class='tag-link-8' title='4 temas' style='font-size: 13.2830188679pt;'>Eventos odontológicos</a>
							<a href='http://www.col.org.pe/web/category/noticias-1/' class='tag-link-6' title='22 temas' style='font-size: 22pt;'>Noticias</a>
							<a href='http://www.col.org.pe/web/category/noticias-2/' class='tag-link-7' title='4 temas' style='font-size: 13.2830188679pt;'>Próximamente</a>
							<a href='http://www.col.org.pe/web/category/sin-categoria/' class='tag-link-1' title='1 tema' style='font-size: 8pt;'>Sin categoría</a>
						</div>
					</div>

					<div id="footer-bottom">
						<p class="left">Copyright © 2012 - Colegio Odontológico de Lima</p>
						<p class="right">
							<!-- inicio codigo contador -->
							<img style="border: 0px solid ; display: inline;" alt="contador de visitas" src="http://contador-de-visitas.com/hit.php?id=1309321&counter=26" width="70" />
							<!-- fin codigo contador -->
							<!--a href='#top' class='backToTop'></a--></p>
					</div>

				</div>

			</div>

		</div>

	</div>
	<!-- END WRAPPER -->

</body>

</html>