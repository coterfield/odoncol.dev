<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['crud_paging'] 			= false;